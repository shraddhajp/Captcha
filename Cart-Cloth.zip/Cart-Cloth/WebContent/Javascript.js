function a(ev)
{
	if (document.getElementById("answer").value==4) 
	{    document.getElementById("answer").value="";
		 document.getElementById("divrobotcheck").innerHTML="<span style='color: #00ffaa'>You are HUMAN.</span><img src='Images/smiliejumpupdown.gif'> ";
	     document.getElementById("subdiv2").innerHTML="<img src='Images/check.png'>";
	}
	else
		{
		document.getElementById("divrobotcheck").innerHTML="Please answer! Prove you are not robot.";
		}
}