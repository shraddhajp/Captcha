function allowDrop(ev) {
	  ev.preventDefault();
	}

	function drag(ev) {
	  ev.dataTransfer.setData("text", ev.target.id);
	}

	function drop(ev) {
	  ev.preventDefault();
	  var data = ev.dataTransfer.getData("text");
	  ev.target.appendChild(document.getElementById(data));
	  
	  document.getElementById("drag1").src="images/anibasket.gif";
	  document.getElementById("div1").style.backgroundImage="";

	  document.getElementById("subdiv1").style.backgroundImage= "url('images/check.png')";
	  document.getElementById("divrobotcheck").innerHTML="<span style='color: #00ffaa'>You are HUMAN.</span><img src='images/smiliejumpupdown.gif'> ";

	  
	  }