

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Timewait
 */
@WebServlet("/Timewait")
public class Timewait extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Timewait() {
        super();
        // TODO Auto-generated constructor stub
    }
int j=0;
int k=0;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		int i=0;	int a[]=new  int[100];

		String range= request.getParameter("data1") ;
		PrintWriter out = response.getWriter();  
		for(i=0;i<100000;i++)
		{
			i=i+1;
	}
		  try {
			   if(k>101)
			    {
			      k=0;
			    }
                j=j+1;          k=k+1; 
	            System.out.println("Starti..." + new Date());
	            /*delay 5 seconds/1000 response.sendRedirect("http://localhost:7003/Golf/Golf.jsp");HttpSession session=request.getSession();  
				session.setAttribute("j",a[k]);
				<%
int i=0;if(session.getAttribute("j")!=null){
   
%>


document.getElementById("scroller").value=<%=session.getAttribute("j")%>+"px";
<%
    };%>*/
	            
	            Thread.sleep(50);
	           
				    
	         
			       
	            a[k]=k;
				System.out.println("session parameter j" +a[k]);
			      
			       out.println("<script>document.getElementById('scroller').value="+k+"</script>");
	            
	            System.out.println("End..." +j+range+ new Date());
	           
	        } catch (InterruptedException e) {
	            System.err.format("IOException: %s%n", e);
	        }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
