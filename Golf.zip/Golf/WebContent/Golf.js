var i=0,o;
function allowDrop(ev) {
	  ev.preventDefault();
	  
	}

	function drag(ev) {
	  ev.dataTransfer.setData("text", ev.target.id);
	}

	function drop(ev) {
	  ev.preventDefault();
	  var data = ev.dataTransfer.getData("text");
	  ev.target.appendChild(document.getElementById(data));

	  document.getElementById("divrobotcheck").innerHTML="<span style='color: #00ffaa'>You are HUMAN.<img src='images/smiliejumpupdown.gif'></span>";
      document.getElementById("check").src= "images/check.png";
      
        
	 
	 
      repeat();
		 
	  }
	
	
	  
	
	  
	  
	  
	  function repeat()	
		{
		  document.getElementById("scroller").value=i;		
		   if(i<101)
		    {
		    	
			   document.getElementById("scroller").value=i;
			    document.getElementById("subdiv4").innerHTML="<div class='alert' id='alert' style='margin-left: "+document.getElementById("scroller").value+"px;'>" 
	        	 +document.getElementById("scroller").value+"</div>";
					              
			     i=i+1;
				  
			   var o=setTimeout(repeat,10);
			   
		   }		

           
        
		}
	  
	  
	  
	  window.onload= function(){
		  document.getElementById("scroller").value="0";
	  }